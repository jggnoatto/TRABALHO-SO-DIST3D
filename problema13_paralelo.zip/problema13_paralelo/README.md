# Problema 13 — Distâncias de pontos 3D (versão paralela)

Este pacote contém somente a implementação paralela em C com `pthreads`, instruções de compilação/execução e um script para coletar tempos brutos. Ele não contém resultados medidos previamente: o CSV deve ser gerado na máquina em que o grupo fará os experimentos.

## 1. Formato da entrada

O programa lê números separados por espaços ou quebras de linha, neste formato:

```text
N
xr yr zr
x1 y1 z1
x2 y2 z2
...
xN yN zN
```

- `N`: quantidade de pontos.
- `xr yr zr`: ponto de referência.
- As próximas `N` triplas são os pontos cuja distância será calculada.

O formato corresponde à descrição do problema 13 no PDF da atividade (página 5): uma primeira linha com `N`, a segunda com o ponto de referência e depois os `N` pontos 3D.

## 2. Compilar

Em Linux, com GCC instalado:

```bash
gcc -O2 -Wall -Wextra -pthread dist3d_paralelo.c -o dist3d_paralelo -lm
```

A opção `-pthread` habilita a compilação/linkagem com pthreads. `-lm` liga a biblioteca matemática usada por `sqrt`. Use a mesma política de otimização (`-O2`, por exemplo) que o integrante responsável pela versão sequencial usar.

## 3. Executar uma vez

Exemplo com 4 threads:

```bash
./dist3d_paralelo entradas/problema13_pequena.txt 4
```

A saída padrão é uma linha CSV com:

```text
N,threads,tempo_ms
```

Para ver também todas as distâncias calculadas (elas são enviadas para `stderr`, sem misturar com a linha de medição):

```bash
./dist3d_paralelo entradas/problema13_pequena.txt 4 --distancias
```

Para usar o máximo de CPUs lógicas online detectadas pelo programa:

```bash
./dist3d_paralelo entradas/problema13_pequena.txt auto
```

## 4. Gerar CSV bruto com repetições individuais

O script executa cada arquivo com 2, 4, 8 e o máximo de CPUs lógicas online, fazendo 3 repetições por configuração. Ele preserva cada medição em uma linha separada, sem calcular médias.

```bash
chmod +x executar_benchmark.sh
./executar_benchmark.sh resultados_paralelo.csv entradas/pequena.txt entradas/media.txt entradas/grande.txt
```

Substitua os nomes de exemplo pelos nomes reais dos três arquivos de entrada fornecidos para o problema 13. Se o máximo de CPUs for 2, 4 ou 8, o script ainda registra a configuração `max` separadamente, conforme solicitado na atividade.

Colunas do CSV:
- `entrada`: arquivo de entrada usado.
- `N`: quantidade de pontos.
- `configuracao`: configuração solicitada (`2`, `4`, `8` ou `max`).
- `threads`: quantidade efetiva de threads criada.
- `repeticao`: número da repetição (1 a 3).
- `tempo_ms`: tempo medido em milissegundos.

A medição começa imediatamente antes da criação das threads e termina após todas terminarem. A leitura do arquivo e a impressão das distâncias ficam fora da região cronometrada. O tempo inclui criação e junção das threads.

## 5. Observações importantes

- Execute a versão paralela sobre as entradas oficiais do trabalho.
- Não use tempos inventados nem copie os tempos de outro computador: gere o CSV na máquina usada pelo grupo.
- A atividade pede pelo menos 3 execuções para cada combinação de entrada e configuração e a preservação dos tempos individuais (PDF, páginas 2 e 7).
- Se o grupo quiser validar a saída, execute com `--distancias` e compare as distâncias com a versão sequencial para a mesma entrada.
- O algoritmo usa `sqrt((x-xr)^2 + (y-yr)^2 + (z-zr)^2)` para cada ponto. Cada thread processa uma faixa disjunta do vetor e grava em posições próprias, evitando disputa de escrita.
