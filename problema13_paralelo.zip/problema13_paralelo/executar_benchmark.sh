#!/usr/bin/env bash
set -euo pipefail

# Uso:
#   ./executar_benchmark.sh entradas/pequena.txt resultados_paralelo.csv
# Passe os tres arquivos de entrada como argumentos adicionais, se desejar:
#   ./executar_benchmark.sh resultados_paralelo.csv pequena.txt media.txt grande.txt

if [[ $# -lt 2 ]]; then
    echo "Uso: $0 <arquivo_csv_saida> <entrada1> [entrada2 ...]" >&2
    exit 1
fi

CSV="$1"
shift
BIN="./dist3d_paralelo"
REPETICOES=3

if [[ ! -x "$BIN" ]]; then
    echo "Executavel $BIN nao encontrado. Compile primeiro conforme o README." >&2
    exit 1
fi

# Descobre o maximo de CPUs logicas online no Linux.
MAX_CPUS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || nproc)"
if [[ -z "$MAX_CPUS" || "$MAX_CPUS" -lt 1 ]]; then MAX_CPUS=1; fi

echo "entrada,N,configuracao,threads, repeticao,tempo_ms" | sed 's/threads, repeticao/threads,repeticao/' > "$CSV"

for entrada in "$@"; do
    if [[ ! -f "$entrada" ]]; then
        echo "Arquivo de entrada nao encontrado: $entrada" >&2
        exit 1
    fi

    # O N e lido da primeira linha do arquivo.
    N="$(head -n 1 "$entrada" | awk '{print $1}')"
    if [[ ! "$N" =~ ^[0-9]+$ ]]; then
        echo "Nao foi possivel ler N da primeira linha de $entrada" >&2
        exit 1
    fi

    # Mantem configuracoes separadas, inclusive quando max coincide com 2, 4 ou 8.
    for config in "2:2" "4:4" "8:8" "max:$MAX_CPUS"; do
        nome="${config%%:*}"
        threads="${config##*:}"

        for repeticao in $(seq 1 "$REPETICOES"); do
            linha="$("$BIN" "$entrada" "$threads")"
            # O programa retorna N, threads realmente usadas e tempo em ms.
            tempo="$(printf '%s\n' "$linha" | awk -F, 'NR==1 {print $3}')"
            threads_reais="$(printf '%s\n' "$linha" | awk -F, 'NR==1 {print $2}')"
            printf '"%s",%s,%s,%s,%s,%s\n' \
                "$entrada" "$N" "$nome" "$threads_reais" "$repeticao" "$tempo" >> "$CSV"
        done
    done
done

echo "Resultados brutos salvos em: $CSV"
